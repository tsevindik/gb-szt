import java.math.BigInteger;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.math.MathContext;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

// =====================================================================
//  Comparison of two reversible sign-encoding schemes for the same
//  core transform (mod-11 flip rule + division by 11/9):
//
//   ZigZag   : ZigZag-based reversible variant
//              flip -> -2v-1, negative -> 2v, ZigZag applied at steps 6, 10, 15, ...
//   Proposed : ZigZag-free variant
//              flip -> -2v, negative -> rank map skipping residues 6 and 16 (mod 22)
//
//  Output: input / encoded / decoded arrays on the console + an Excel workbook (comparison.xlsx) in the sketch folder.
//  No external libraries are required (the .xlsx file is written with java.util.zip).
// =====================================================================

// -------------------- Experiment configuration --------------------
final int TOTAL_STEPS = 114;                     // step count shown on the console
final int[] STEP_COUNTS = {1, 10, 50, 114, 300};
final int RANGE_MAX = 2000;                      // every integer in 0..RANGE_MAX is tested
final String OUTPUT_FILE = "comparison.xlsx";

final String[] INPUT_ARRAY_STRINGS = {
    "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10",
    "11", "12", "13", "14", "15", "16", "17", "18", "19", "20",
    "50", "500", "5000", "50000", "500000", "5000000", "2000000000",
    "9223372036854775808", "497500300327648119726888888888999999999",
    "100000000000000000000000000000000000000000000"
};

// -------------------- Transform constants --------------------
final int PRECISION = 1000;
final int TUNER_PRECISION = 100;
final int MODULUS = 11;

final MathContext MC = new MathContext(PRECISION, RoundingMode.HALF_UP);
final BigInteger ZERO = BigInteger.ZERO;
final BigInteger ONE = BigInteger.ONE;
final BigInteger FIVE = BigInteger.valueOf(5);
final BigInteger TWO = BigInteger.valueOf(2);
final BigInteger MOD = BigInteger.valueOf(MODULUS);
final BigInteger B20 = BigInteger.valueOf(20);
final BigInteger B22 = BigInteger.valueOf(22);
// Residues 1..22 excluding 6 and 16 (the residues mod 22 taken by flipped values -2v)
final int[] FREE = {1,2,3,4,5,7,8,9,10,11,12,13,14,15,17,18,19,20,21,22};
BigDecimal TUNER;
BigDecimal INV_TUNER;

final int MODE_ZIGZAG = 0, MODE_PROPOSED = 1;

// -------------------- Result record --------------------
class Result {
  int steps;
  long inputBits, zzBits, prBits, zzErrors, prErrors, zzMax, prMax;
  double reduction, ratio, zzGrowth, prGrowth, winPct, tiePct, lossPct;
}

// -------------------- Main --------------------
void setup() {
  Locale.setDefault(Locale.ROOT);   // decimal point '.', independent of system locale
  TUNER = new BigDecimal("1." + repeat('2', TUNER_PRECISION));
  INV_TUNER = BigDecimal.ONE.divide(TUNER, MC);

  BigInteger[] inputArray = new BigInteger[INPUT_ARRAY_STRINGS.length];
  for (int i = 0; i < inputArray.length; i++) inputArray[i] = new BigInteger(INPUT_ARRAY_STRINGS[i]);

  BigInteger[] fullRange = new BigInteger[RANGE_MAX + 1];
  for (int i = 0; i <= RANGE_MAX; i++) fullRange[i] = BigInteger.valueOf(i);

  println("=== Lossless Transform Encoder/Decoder: ZigZag vs. Proposed ===");
  println("TOTAL_STEPS: " + TOTAL_STEPS);
  println("INPUT_ARRAY Size: " + inputArray.length);
  println("");
  println("Input (Total " + inputArray.length + " elements): " + Arrays.toString(inputArray));

  for (int mode = MODE_ZIGZAG; mode <= MODE_PROPOSED; mode++) {
    BigInteger[] encoded = new BigInteger[inputArray.length];
    BigInteger[] decoded = new BigInteger[inputArray.length];
    for (int i = 0; i < inputArray.length; i++) {
      encoded[i] = forward(inputArray[i], TOTAL_STEPS, mode);
      decoded[i] = inverse(encoded[i], TOTAL_STEPS, mode);
    }
    println("");
    println("----- " + (mode == MODE_ZIGZAG ? "ZigZag method" : "Proposed method") + " -----");
    println("Encoded (Final Array): " + Arrays.toString(encoded));
    println("Decoded: " + Arrays.toString(decoded));
    println("Reversible: " + Arrays.equals(inputArray, decoded));
  }

  ArrayList<Result> arrayResults = evaluate(inputArray);
  ArrayList<Result> rangeResults = evaluate(fullRange);
  writeWorkbook(sketchPath(OUTPUT_FILE), arrayResults, rangeResults, inputArray, fullRange);
  println("");
  println("Excel workbook written: " + sketchPath(OUTPUT_FILE));
}

// -------------------- Evaluation --------------------
ArrayList<Result> evaluate(BigInteger[] data) {
  ArrayList<Result> out = new ArrayList<Result>();
  long inputBits = 0;
  for (BigInteger x : data) inputBits += x.bitLength() + 1;

  for (int steps : STEP_COUNTS) {
    long[] zz = encodedBits(data, steps, MODE_ZIGZAG);
    long[] pr = encodedBits(data, steps, MODE_PROPOSED);
    int n = data.length;
    Result r = new Result();
    r.steps = steps;
    r.inputBits = inputBits;
    r.zzErrors = zz[n];
    r.prErrors = pr[n];
    int win = 0, tie = 0, loss = 0;
    for (int i = 0; i < n; i++) {
      r.zzBits += zz[i];
      r.prBits += pr[i];
      r.zzMax = Math.max(r.zzMax, zz[i]);
      r.prMax = Math.max(r.prMax, pr[i]);
      if (pr[i] < zz[i]) win++; else if (pr[i] == zz[i]) tie++; else loss++;
    }
    r.reduction = 100.0 * (r.zzBits - r.prBits) / r.zzBits;
    r.ratio     = (double) r.zzBits / r.prBits;
    r.zzGrowth  = 100.0 * (r.zzBits - inputBits) / inputBits;
    r.prGrowth  = 100.0 * (r.prBits - inputBits) / inputBits;
    r.winPct  = 100.0 * win / n;
    r.tiePct  = 100.0 * tie / n;
    r.lossPct = 100.0 * loss / n;
    out.add(r);
  }
  return out;
}

// Encoded bit length of every element; the last entry holds the number of decoding errors.
long[] encodedBits(BigInteger[] data, int steps, int mode) {
  long[] out = new long[data.length + 1];
  for (int i = 0; i < data.length; i++) {
    BigInteger e = forward(data[i], steps, mode);
    if (!inverse(e, steps, mode).equals(data[i])) out[data.length]++;
    out[i] = e.bitLength() + 1;
  }
  return out;
}

// -------------------- Utilities --------------------
String repeat(char c, int n) { StringBuilder sb = new StringBuilder(); for (int i = 0; i < n; i++) sb.append(c); return sb.toString(); }
String pad(String s, int w) { StringBuilder sb = new StringBuilder(s); while (sb.length() < w) sb.append(' '); return sb.toString(); }
String f(double x, int decimals) { return String.format(Locale.ROOT, "%." + decimals + "f", x); }

boolean shouldFlip(BigInteger v) { int r = v.mod(MOD).intValue(); return r == 3 || r == 8; }

BigInteger divTuner(BigInteger v) { return new BigDecimal(v).multiply(INV_TUNER, MC).setScale(0, RoundingMode.HALF_UP).toBigInteger(); }
BigInteger mulTuner(BigInteger v) { return new BigDecimal(v).multiply(TUNER, MC).setScale(0, RoundingMode.HALF_UP).toBigInteger(); }

BigInteger applyZigZag(BigInteger v)   { return v.signum() >= 0 ? v.multiply(TWO) : v.negate().multiply(TWO).subtract(ONE); }
BigInteger reverseZigZag(BigInteger v) { return v.testBit(0) ? v.add(ONE).divide(TWO).negate() : v.divide(TWO); }

boolean isZigZagStep(int s, int steps) { return ((s + 1) == 6 || ((s + 1) >= 10 && (s + 1) % 5 == 0)) && s != steps - 1; }

// Proposed method: negative-branch rank map (skips residues 6 and 16 mod 22)
boolean isFlipMark(BigInteger mag) { int r = mag.mod(B22).intValue(); return r == 6 || r == 16; }

BigInteger negMap(BigInteger m) {            // m >= 1  ->  m-th positive integer not in {6, 16} mod 22
  BigInteger[] qr = m.subtract(ONE).divideAndRemainder(B20);
  return qr[0].multiply(B22).add(BigInteger.valueOf(FREE[qr[1].intValue()]));
}

BigInteger negUnmap(BigInteger M) {          // inverse of negMap
  BigInteger q = M.subtract(ONE).divide(B22);
  int a = M.subtract(q.multiply(B22)).intValue();
  int r = 0;
  while (FREE[r] != a) r++;
  return q.multiply(B20).add(BigInteger.valueOf(r + 1));
}

// -------------------- Forward transform --------------------
// One forward step s (0-based) of a run with 'steps' total steps
BigInteger forwardStep(BigInteger v, int s, int steps, int mode) {
  if (v.signum() != 0) {
    if (v.signum() > 0) {
      if (shouldFlip(v)) {                                     // residue 3 or 8 mod 11
        if (mode == MODE_ZIGZAG) v = v.multiply(TWO).add(ONE).negate();   // -2v-1
        else                     v = v.multiply(TWO).negate();            // -2v
      } else {
        v = divTuner(v);                                       // round(v / (11/9))
      }
    } else {
      if (mode == MODE_ZIGZAG) v = v.multiply(TWO);            // 2v
      else                     v = negMap(v.negate()).negate();
    }
    if (s % 3 == 2 && v.signum() < 0) v = v.subtract(MOD);
    if (v.mod(MOD).intValue() == MODULUS - 4) v = v.add(MOD);
  }
  if ((s + 1) % 5 == 0) v = FIVE.subtract(v);
  if (mode == MODE_ZIGZAG && isZigZagStep(s, steps)) v = applyZigZag(v);
  return v;
}

BigInteger forward(BigInteger v, int steps, int mode) {
  for (int s = 0; s < steps; s++) v = forwardStep(v, s, steps, mode);
  return v;
}

// Value after every step: trace[0] = input, trace[k] = value after step k
BigInteger[] forwardTrace(BigInteger v, int steps, int mode) {
  BigInteger[] trace = new BigInteger[steps + 1];
  trace[0] = v;
  for (int s = 0; s < steps; s++) {
    v = forwardStep(v, s, steps, mode);
    trace[s + 1] = v;
  }
  return trace;
}

// -------------------- Inverse transform --------------------
BigInteger inverse(BigInteger v, int steps, int mode) {
  for (int s = steps - 1; s >= 0; s--) {
    if (mode == MODE_ZIGZAG && isZigZagStep(s, steps)) v = reverseZigZag(v);
    if ((s + 1) % 5 == 0) v = FIVE.subtract(v);
    if (v.signum() == 0) continue;

    if (v.mod(MOD).intValue() == MODULUS - 4) v = v.subtract(MOD);
    if (s % 3 == 2 && v.signum() < 0) v = v.add(MOD);

    if (v.signum() < 0) {
      BigInteger mag = v.negate();
      if (mode == MODE_ZIGZAG) {
        v = v.testBit(0) ? mag.subtract(ONE).divide(TWO) : v.divide(TWO);
      } else {
        v = isFlipMark(mag) ? mag.divide(TWO) : negUnmap(mag).negate();
      }
    } else {
      v = mulTuner(v);
    }
  }
  return v;
}

// =====================================================================
//  Excel (.xlsx) output - minimal Office Open XML writer, no dependencies
// =====================================================================
final int ST_TEXT = 0, ST_HEADER = 1, ST_INT = 2, ST_DEC = 3, ST_TITLE = 4, ST_WRAP = 5, ST_TEXT_PLAIN = 6;

class Sheet {
  String name;
  StringBuilder rows = new StringBuilder();
  int rowCount = 0;
  int freezeRows = 0;
  int freezeCols = 0;
  double[] widths;
  Sheet(String name, double[] widths) { this.name = name; this.widths = widths; }

  void addRow(Object[] cells, int[] styles) {
    rowCount++;
    rows.append("<row r=\"").append(rowCount).append("\">");
    for (int c = 0; c < cells.length; c++) {
      if (cells[c] == null) continue;
      String ref = colName(c) + rowCount;
      int st = styles[Math.min(c, styles.length - 1)];
      Object v = cells[c];
      if (v instanceof Number) {
        String num = (v instanceof Double) ? String.format(Locale.ROOT, "%.6f", (Double) v) : v.toString();
        rows.append("<c r=\"").append(ref).append("\" s=\"").append(st).append("\"><v>").append(num).append("</v></c>");
      } else {
        rows.append("<c r=\"").append(ref).append("\" s=\"").append(st).append("\" t=\"inlineStr\"><is><t xml:space=\"preserve\">")
            .append(xmlEscape(v.toString())).append("</t></is></c>");
      }
    }
    rows.append("</row>");
  }

  void addBlank() { rowCount++; }

  String toXml() {
    StringBuilder sb = new StringBuilder();
    sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
    sb.append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">");
    sb.append("<sheetViews><sheetView workbookViewId=\"0\">");
    if (freezeRows > 0 || freezeCols > 0) {
      sb.append("<pane");
      if (freezeCols > 0) sb.append(" xSplit=\"").append(freezeCols).append("\"");
      if (freezeRows > 0) sb.append(" ySplit=\"").append(freezeRows).append("\"");
      String pane = (freezeRows > 0 && freezeCols > 0) ? "bottomRight" : (freezeRows > 0 ? "bottomLeft" : "topRight");
      sb.append(" topLeftCell=\"").append(colName(freezeCols)).append(freezeRows + 1)
        .append("\" activePane=\"").append(pane).append("\" state=\"frozen\"/>");
    }
    sb.append("</sheetView></sheetViews><cols>");
    for (int c = 0; c < widths.length; c++)
      sb.append("<col min=\"").append(c + 1).append("\" max=\"").append(c + 1).append("\" width=\"")
        .append(String.format(Locale.ROOT, "%.1f", widths[c])).append("\" customWidth=\"1\"/>");
    sb.append("</cols><sheetData>").append(rows).append("</sheetData></worksheet>");
    return sb.toString();
  }
}

String colName(int c) { String s = ""; c++; while (c > 0) { int m = (c - 1) % 26; s = (char) ('A' + m) + s; c = (c - 1) / 26; } return s; }
String xmlEscape(String s) { return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;"); }

final String[] RESULT_HEADERS = {
  "Steps", "Input bits", "ZigZag bits", "Proposed bits",
  "ZigZag decoding errors", "Proposed decoding errors",
  "Bit reduction (%)", "Size ratio (ZigZag / Proposed)",
  "ZigZag growth vs. input (%)", "Proposed growth vs. input (%)",
  "Proposed smaller (%)", "Equal (%)", "Proposed larger (%)",
  "ZigZag max bits", "Proposed max bits"
};

Sheet resultSheet(String name, String title, ArrayList<Result> results) {
  double[] w = {8, 12, 13, 14, 14, 14, 12, 16, 16, 16, 14, 10, 14, 12, 13};
  Sheet sh = new Sheet(name, w);
  sh.addRow(new Object[]{title}, new int[]{ST_TITLE});
  sh.addBlank();
  sh.addRow(RESULT_HEADERS, new int[]{ST_HEADER});
  sh.freezeRows = 3;
  int[] st = {ST_INT, ST_INT, ST_INT, ST_INT, ST_INT, ST_INT, ST_DEC, ST_DEC, ST_DEC, ST_DEC, ST_DEC, ST_DEC, ST_DEC, ST_INT, ST_INT};
  for (Result r : results) {
    sh.addRow(new Object[]{
      r.steps, r.inputBits, r.zzBits, r.prBits, r.zzErrors, r.prErrors,
      r.reduction, r.ratio, r.zzGrowth, r.prGrowth, r.winPct, r.tiePct, r.lossPct, r.zzMax, r.prMax
    }, st);
  }
  return sh;
}

Sheet definitionsSheet(int arraySize, int rangeSize) {
  Sheet sh = new Sheet("Definitions", new double[]{34, 100});
  int[] kv = {ST_HEADER, ST_WRAP};
  sh.addRow(new Object[]{"Metric definitions and experimental setup"}, new int[]{ST_TITLE});
  sh.addBlank();
  sh.addRow(new Object[]{"Item", "Definition"}, new int[]{ST_HEADER});
  sh.freezeRows = 3;
  sh.addRow(new Object[]{"Bits", "Binary length of each encoded integer including one sign bit (bitLength + 1), summed over all elements."}, kv);
  sh.addRow(new Object[]{"Input bits", "Total bits of the original (unencoded) inputs, measured the same way."}, kv);
  sh.addRow(new Object[]{"Bit reduction (%)", "(ZigZag bits - Proposed bits) / ZigZag bits x 100."}, kv);
  sh.addRow(new Object[]{"Size ratio", "ZigZag bits / Proposed bits."}, kv);
  sh.addRow(new Object[]{"Growth vs. input (%)", "(Method bits - Input bits) / Input bits x 100."}, kv);
  sh.addRow(new Object[]{"Smaller / Equal / Larger (%)", "Share of elements whose Proposed encoding is shorter than, equal to, or longer than the ZigZag encoding."}, kv);
  sh.addRow(new Object[]{"Decoding errors", "Number of elements for which inverse(forward(x)) != x. Zero means lossless on the tested set."}, kv);
  sh.addRow(new Object[]{"ZigZag method", "Flip (v mod 11 in {3, 8}) -> -2v-1; negative v -> 2v; ZigZag applied after steps 6, 10, 15, 20, ... (except the last step)."}, kv);
  sh.addRow(new Object[]{"Proposed method", "Flip (v mod 11 in {3, 8}) -> -2v; negative v -> -(m-th positive integer whose residue mod 22 is not 6 or 16), m = |v|; no ZigZag."}, kv);
  sh.addRow(new Object[]{"Shared core", "Positive v not flipped -> round(v / T), T = 1.222...2 (" + TUNER_PRECISION + " digits, approximating 11/9); identical in both methods."}, kv);
  sh.addRow(new Object[]{"Step counts tested", join(STEP_COUNTS)}, kv);
  sh.addRow(new Object[]{"Input array size", Integer.toString(arraySize)}, kv);
  sh.addRow(new Object[]{"Full range", "All integers 0.." + RANGE_MAX + " (" + rangeSize + " elements)"}, kv);
  sh.addRow(new Object[]{"Trace sheets", "Step-by-step values for TOTAL_STEPS = " + TOTAL_STEPS + ". 'Trace' sheets: input array (rows = steps). 'Range Trace' sheets: all integers 0.." + RANGE_MAX + " (rows = integers, columns = steps). Integers with more than 15 digits are stored as text to preserve exact values."}, kv);
  return sh;
}

// Exact values are kept: integers with more than 15 digits are written as text,
// because Excel stores numbers as 64-bit floating point (15 significant digits).
Object excelValue(BigInteger v) {
  return v.abs().toString().length() <= 15 ? (Object) Long.valueOf(v.longValue()) : (Object) v.toString();
}

Sheet traceSheet(String name, String title, BigInteger[] inputs, int mode) {
  BigInteger[][] traces = new BigInteger[inputs.length][];
  for (int i = 0; i < inputs.length; i++) traces[i] = forwardTrace(inputs[i], TOTAL_STEPS, mode);

  double[] w = new double[inputs.length + 1];
  w[0] = 8;
  for (int i = 0; i < inputs.length; i++) {
    int len = 6;
    for (BigInteger v : traces[i]) len = Math.max(len, v.toString().length());
    w[i + 1] = Math.min(len + 2, 60);
  }
  Sheet sh = new Sheet(name, w);
  sh.addRow(new Object[]{title}, new int[]{ST_TITLE});
  sh.addRow(new Object[]{"Rows: step number (0 = input). Columns: input values. Cells: value after that step. Values with more than 15 digits are stored as text to keep them exact."}, new int[]{ST_TEXT_PLAIN});
  Object[] header = new Object[inputs.length + 1];
  header[0] = "Step";
  for (int i = 0; i < inputs.length; i++) header[i + 1] = "x = " + inputs[i];
  sh.addRow(header, new int[]{ST_HEADER});
  sh.freezeRows = 3;
  sh.freezeCols = 1;
  int[] st = new int[inputs.length + 1];
  st[0] = ST_HEADER;
  for (int i = 1; i < st.length; i++) st[i] = ST_INT;
  for (int k = 0; k <= TOTAL_STEPS; k++) {
    Object[] row = new Object[inputs.length + 1];
    row[0] = k;
    for (int i = 0; i < inputs.length; i++) row[i + 1] = excelValue(traces[i][k]);
    sh.addRow(row, st);
  }
  return sh;
}

// Range trace: one row per input value, one column per step (0 = input, TOTAL_STEPS = encoded)
Sheet rangeTraceSheet(String name, String title, BigInteger[] inputs, int mode) {
  int cols = TOTAL_STEPS + 1;
  BigInteger[][] traces = new BigInteger[inputs.length][];
  int[] maxLen = new int[cols];
  for (int i = 0; i < inputs.length; i++) {
    traces[i] = forwardTrace(inputs[i], TOTAL_STEPS, mode);
    for (int k = 0; k < cols; k++) maxLen[k] = Math.max(maxLen[k], traces[i][k].toString().length());
  }
  double[] w = new double[cols + 1];
  w[0] = 8;
  for (int k = 0; k < cols; k++) w[k + 1] = Math.min(Math.max(maxLen[k], 6) + 2, 60);

  Sheet sh = new Sheet(name, w);
  sh.addRow(new Object[]{title}, new int[]{ST_TITLE});
  sh.addRow(new Object[]{"Rows: input value x. Columns: step number (Step 0 = input, Step " + TOTAL_STEPS + " = encoded). Values with more than 15 digits are stored as text to keep them exact."}, new int[]{ST_TEXT_PLAIN});
  Object[] header = new Object[cols + 1];
  header[0] = "x";
  for (int k = 0; k < cols; k++) header[k + 1] = "Step " + k;
  sh.addRow(header, new int[]{ST_HEADER});
  sh.freezeRows = 3;
  sh.freezeCols = 1;
  int[] st = new int[cols + 1];
  st[0] = ST_HEADER;
  for (int k = 1; k < st.length; k++) st[k] = ST_INT;
  for (int i = 0; i < inputs.length; i++) {
    Object[] row = new Object[cols + 1];
    row[0] = excelValue(inputs[i]);
    for (int k = 0; k < cols; k++) row[k + 1] = excelValue(traces[i][k]);
    sh.addRow(row, st);
  }
  return sh;
}

Sheet bitGrowthSheet(BigInteger[] inputs) {
  Sheet sh = new Sheet("Bit Growth per Step", new double[]{8, 14, 14, 14, 16, 16});
  sh.addRow(new Object[]{"Total encoded size of the input array after each step (" + inputs.length + " elements, " + TOTAL_STEPS + " steps)"}, new int[]{ST_TITLE});
  sh.addRow(new Object[]{"Bits = sum over all elements of (bitLength + 1). Suitable for a line chart of size vs. step."}, new int[]{ST_TEXT_PLAIN});
  sh.addRow(new Object[]{"Step", "Input bits", "ZigZag bits", "Proposed bits", "Size ratio (ZigZag / Proposed)", "Bit reduction (%)"}, new int[]{ST_HEADER});
  sh.freezeRows = 3;
  BigInteger[][] zz = new BigInteger[inputs.length][];
  BigInteger[][] pr = new BigInteger[inputs.length][];
  long inBits = 0;
  for (int i = 0; i < inputs.length; i++) {
    zz[i] = forwardTrace(inputs[i], TOTAL_STEPS, MODE_ZIGZAG);
    pr[i] = forwardTrace(inputs[i], TOTAL_STEPS, MODE_PROPOSED);
    inBits += inputs[i].bitLength() + 1;
  }
  int[] st = {ST_INT, ST_INT, ST_INT, ST_INT, ST_DEC, ST_DEC};
  for (int k = 0; k <= TOTAL_STEPS; k++) {
    long z = 0, p = 0;
    for (int i = 0; i < inputs.length; i++) { z += zz[i][k].bitLength() + 1; p += pr[i][k].bitLength() + 1; }
    sh.addRow(new Object[]{k, inBits, z, p, (double) z / p, 100.0 * (z - p) / z}, st);
  }
  return sh;
}

String join(int[] a) { StringBuilder sb = new StringBuilder(); for (int i = 0; i < a.length; i++) { if (i > 0) sb.append(", "); sb.append(a[i]); } return sb.toString(); }

String stylesXml() {
  return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
    + "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">"
    + "<numFmts count=\"1\"><numFmt numFmtId=\"164\" formatCode=\"0.00\"/></numFmts>"
    + "<fonts count=\"3\">"
    +   "<font><sz val=\"11\"/><name val=\"Calibri\"/></font>"
    +   "<font><b/><sz val=\"11\"/><color rgb=\"FFFFFFFF\"/><name val=\"Calibri\"/></font>"
    +   "<font><b/><sz val=\"13\"/><name val=\"Calibri\"/></font>"
    + "</fonts>"
    + "<fills count=\"3\">"
    +   "<fill><patternFill patternType=\"none\"/></fill>"
    +   "<fill><patternFill patternType=\"gray125\"/></fill>"
    +   "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF1F4E79\"/><bgColor indexed=\"64\"/></patternFill></fill>"
    + "</fills>"
    + "<borders count=\"2\">"
    +   "<border><left/><right/><top/><bottom/><diagonal/></border>"
    +   "<border><left style=\"thin\"><color rgb=\"FFBFBFBF\"/></left><right style=\"thin\"><color rgb=\"FFBFBFBF\"/></right>"
    +   "<top style=\"thin\"><color rgb=\"FFBFBFBF\"/></top><bottom style=\"thin\"><color rgb=\"FFBFBFBF\"/></bottom><diagonal/></border>"
    + "</borders>"
    + "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>"
    + "<cellXfs count=\"7\">"
    +   "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyBorder=\"1\"/>"
    +   "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"1\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyBorder=\"1\" applyAlignment=\"1\">"
    +     "<alignment horizontal=\"center\" vertical=\"center\" wrapText=\"1\"/></xf>"
    +   "<xf numFmtId=\"1\" fontId=\"0\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyNumberFormat=\"1\" applyBorder=\"1\"/>"
    +   "<xf numFmtId=\"164\" fontId=\"0\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyNumberFormat=\"1\" applyBorder=\"1\"/>"
    +   "<xf numFmtId=\"0\" fontId=\"2\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/>"
    +   "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyBorder=\"1\" applyAlignment=\"1\">"
    +     "<alignment vertical=\"top\" wrapText=\"1\"/></xf>"
    +   "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>"
    + "</cellXfs>"
    + "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles>"
    + "</styleSheet>";
}

void writeWorkbook(String path, ArrayList<Result> arrayResults, ArrayList<Result> rangeResults, BigInteger[] inputArray, BigInteger[] fullRange) {
  int rangeSize = fullRange.length;
  int arraySize = inputArray.length;
  Sheet[] sheets = {
    resultSheet("Full Range", "ZigZag vs. Proposed - all integers 0.." + RANGE_MAX + " (" + rangeSize + " elements)", rangeResults),
    resultSheet("Input Array", "ZigZag vs. Proposed - input array (" + arraySize + " elements)", arrayResults),
    bitGrowthSheet(inputArray),
    traceSheet("Trace - Proposed", "Proposed method - value of each input after every step (TOTAL_STEPS = " + TOTAL_STEPS + ")", inputArray, MODE_PROPOSED),
    traceSheet("Trace - ZigZag", "ZigZag method - value of each input after every step (TOTAL_STEPS = " + TOTAL_STEPS + ")", inputArray, MODE_ZIGZAG),
    rangeTraceSheet("Range Trace - Proposed", "Proposed method - every integer 0.." + RANGE_MAX + " after every step (TOTAL_STEPS = " + TOTAL_STEPS + ")", fullRange, MODE_PROPOSED),
    rangeTraceSheet("Range Trace - ZigZag", "ZigZag method - every integer 0.." + RANGE_MAX + " after every step (TOTAL_STEPS = " + TOTAL_STEPS + ")", fullRange, MODE_ZIGZAG),
    definitionsSheet(arraySize, rangeSize)
  };

  StringBuilder ct = new StringBuilder();
  ct.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
    .append("<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">")
    .append("<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>")
    .append("<Default Extension=\"xml\" ContentType=\"application/xml\"/>")
    .append("<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>")
    .append("<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>");
  for (int i = 0; i < sheets.length; i++)
    ct.append("<Override PartName=\"/xl/worksheets/sheet").append(i + 1)
      .append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
  ct.append("</Types>");

  String rootRels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
    + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
    + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>"
    + "</Relationships>";

  StringBuilder wb = new StringBuilder();
  wb.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
    .append("<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" ")
    .append("xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>");
  StringBuilder wbRels = new StringBuilder();
  wbRels.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
        .append("<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
  for (int i = 0; i < sheets.length; i++) {
    wb.append("<sheet name=\"").append(xmlEscape(sheets[i].name)).append("\" sheetId=\"").append(i + 1)
      .append("\" r:id=\"rId").append(i + 1).append("\"/>");
    wbRels.append("<Relationship Id=\"rId").append(i + 1)
          .append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet")
          .append(i + 1).append(".xml\"/>");
  }
  wb.append("</sheets></workbook>");
  wbRels.append("<Relationship Id=\"rId").append(sheets.length + 1)
        .append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>")
        .append("</Relationships>");

  try {
    ZipOutputStream zip = new ZipOutputStream(new FileOutputStream(path));
    zipEntry(zip, "[Content_Types].xml", ct.toString());
    zipEntry(zip, "_rels/.rels", rootRels);
    zipEntry(zip, "xl/workbook.xml", wb.toString());
    zipEntry(zip, "xl/_rels/workbook.xml.rels", wbRels.toString());
    zipEntry(zip, "xl/styles.xml", stylesXml());
    for (int i = 0; i < sheets.length; i++) zipEntry(zip, "xl/worksheets/sheet" + (i + 1) + ".xml", sheets[i].toXml());
    zip.close();
  } catch (Exception e) {
    println("ERROR: could not write Excel file: " + e);
  }
}

void zipEntry(ZipOutputStream zip, String name, String content) throws java.io.IOException {
  zip.putNextEntry(new ZipEntry(name));
  zip.write(content.getBytes(StandardCharsets.UTF_8));
  zip.closeEntry();
}
