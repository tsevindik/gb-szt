import java.math.BigInteger;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.math.MathContext;
import java.util.Arrays;

// -------------------- Configuration and Constraints --------------------
final int TOTAL_STEPS  = 114;

// *** INPUT DİZİSİ TANIMLANIYOR ***
final String[] INPUT_ARRAY_STRINGS = {
    "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10",  
    "11", "12", "13", "14", "15", "16", "17", "18", "19", "20",
    "50", "500", "5000", "50000", "500000", "5000000", "2000000000",  
    "9223372036854775808", "497500300327648119726888888888999999999",
    "100000000000000000000000000000000000000000000"  
};


// -------------------- Transform Constants --------------------
final int PRECISION = 1000;
final int TUNER_PRECISION = 100;
final int MODULUS = 11;

final MathContext MC = new MathContext(PRECISION, RoundingMode.HALF_UP);
final BigInteger ZERO = BigInteger.ZERO;
final BigInteger ONE = BigInteger.ONE;
final BigInteger MINUS_ONE = BigInteger.valueOf(-1);
final BigInteger FIVE = BigInteger.valueOf(5);
final BigInteger TWO = BigInteger.valueOf(2);
final BigInteger MOD = BigInteger.valueOf(MODULUS);
BigDecimal TUNER;
BigDecimal INV_TUNER;


// -------------------- Main Processing Method --------------------
void setup() {
  println("=== Lossless Transform Encoder/Decoder (ZigZag Integrated) ===");
  println("TOTAL_STEPS: " + TOTAL_STEPS);
  println("INPUT_ARRAY Size: " + INPUT_ARRAY_STRINGS.length);
  println();

  if (TOTAL_STEPS < 1) {
    println("CRITICAL ERROR: Total number of steps must be at least 1. Found: " + TOTAL_STEPS + ".");
    exit();
  }
  
  TUNER = new BigDecimal(createTunerString(TUNER_PRECISION));
  INV_TUNER = BigDecimal.ONE.divide(TUNER, MC);

  BigInteger[] input = stringArrayToBigInt(INPUT_ARRAY_STRINGS);
  
  println("Input (Total " + input.length + " elements): " + Arrays.toString(input));

  BigInteger[] encoded = encode(input, TOTAL_STEPS);
  println("\nEncoded (Final Array): " + Arrays.toString(encoded));

  BigInteger[] decoded = decode(encoded, TOTAL_STEPS);
  println("\nDecoded: " + Arrays.toString(decoded));
  
  println("Reversible: " + Arrays.equals(input, decoded));
}

// -------------------- Utilities --------------------

String createTunerString(int precision) {
  StringBuilder sb = new StringBuilder("1.");
  for (int i=0; i<precision; i++) sb.append('2');
  return sb.toString();
}

BigInteger[] stringArrayToBigInt(String[] arr){
    BigInteger[] out = new BigInteger[arr.length];
    for (int i=0; i<arr.length; i++) {
        BigInteger value;
        try {
            value = new BigInteger(arr[i]);
        } catch (NumberFormatException e) {
            println("CRITICAL ERROR: Invalid number format in input string array: " + arr[i]);
            exit();
            return null; 
        }
        if (value.compareTo(ZERO) < 0) {
            println("CRITICAL ERROR: Input array must contain only non-negative (natural) numbers. Found negative value: " + arr[i] + ".");
            exit();
        }
        out[i] = value;
    }
    return out;
}

boolean shouldFlip(BigInteger v){
  int r = v.mod(MOD).intValue();
  return r == 3 || r == 8;
}

// --- ZigZag Encoding / Decoding Methods ---
BigInteger applyZigZag(BigInteger v) {
  if (v.compareTo(ZERO) >= 0) {
    return v.multiply(TWO);
  } else {
    return v.negate().multiply(TWO).subtract(ONE);
  }
}

BigInteger reverseZigZag(BigInteger v) {
  if (v.mod(TWO).equals(ZERO)) {
    return v.divide(TWO);
  } else {
    return v.add(ONE).divide(TWO).negate();
  }
}


// -------------------- Forward / Inverse Transform Methods --------------------

BigInteger[] forwardTransform(BigInteger[] arr, int steps) {
  BigInteger[] res = arr.clone();
  for (int i = 0; i < res.length; i++) {
    BigInteger v = res[i];
    for (int s = 0; s < steps; s++) {
      if (v.equals(ZERO)) {
        if ((s + 1) % 5 == 0) {
          v = v.multiply(MINUS_ONE).add(FIVE);
        }
        continue;
      }

      if (v.compareTo(ZERO) > 0) { 
        if (shouldFlip(v)) {
          v = v.negate();
        } else {
          BigDecimal scaled = new BigDecimal(v).multiply(INV_TUNER, MC);
          v = scaled.setScale(0, RoundingMode.HALF_UP).toBigInteger();
        }
      } else { 
        v = v.add(ONE);
      }

      if (s % 3 == 2 && v.compareTo(ZERO) < 0) v = v.subtract(MOD);
      int rem = v.mod(MOD).intValue();
      if (rem == (MODULUS - 4)) v = v.add(MOD);
      
      if ((s + 1) % 5 == 0) {
        v = v.multiply(MINUS_ONE).add(FIVE);
      }

      if ((s + 1) == 6 || ((s + 1) >= 10 && (s + 1) % 5 == 0)) {
        if (s == steps - 1) {
          // Son adım ise encoded dizide orijinal (işaretli/işaretsiz) hali kalır, değişmez.
        } else {
          // Ara adımlardaysa bir sonraki adıma ZigZag uygulanmış hali yollanır.
          v = applyZigZag(v);
        }
      }
    }
    res[i] = v;
  }
  return res;
}

BigInteger[] inverseTransform(BigInteger[] arr, int steps) {
  BigInteger[] res = arr.clone();
  for (int i = 0; i < res.length; i++) {
    BigInteger v = res[i];
    for (int s = steps - 1; s >= 0; s--) {
      
      if ((s + 1) == 6 || ((s + 1) >= 10 && (s + 1) % 5 == 0)) {
        if (s == steps - 1) {
          // Son adımdan geri başlanıyorsa encoded içindeki orijinal sayı aynen alınır.
        } else {
          // Ara adımdan geliniyorsa gelen ZigZag uygulanmış sayı orijinal haline geri çevrilir.
          v = reverseZigZag(v);
        }
      }

      if ((s + 1) % 5 == 0) {
        v = v.subtract(FIVE).multiply(MINUS_ONE);
      }

      if (v.equals(ZERO)) {
        continue;
      }

      int rem = v.mod(MOD).intValue();
      if (rem == (MODULUS - 4)) v = v.subtract(MOD);
      if (s % 3 == 2 && v.compareTo(ZERO) < 0) v = v.add(MOD);

      if (v.compareTo(ZERO) < 0) { 
        BigInteger mag = v.negate();
        if (shouldFlip(mag)) {
          v = v.negate(); 
        } else {
          v = v.subtract(ONE); 
        }
      } else { 
        BigDecimal scaled = new BigDecimal(v).multiply(TUNER, MC);
        v = scaled.setScale(0, RoundingMode.HALF_UP).toBigInteger();
      }
    }
    res[i] = v;
  }
  return res;
}

// -------------------- Encode / Decode Core Logic --------------------

BigInteger[] encode(BigInteger[] input, int totalSteps) {
  return forwardTransform(input, totalSteps);
}

BigInteger[] decode(BigInteger[] encoded, int totalSteps) {
  return inverseTransform(encoded, totalSteps);
}
